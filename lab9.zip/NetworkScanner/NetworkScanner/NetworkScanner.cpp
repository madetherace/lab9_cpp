﻿#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

#ifdef _WIN32
#define PING_COMMAND "ping -n 1 -w 1000 "
#else
#define PING_COMMAND "ping -c 1 -W 1 "
#endif

bool isHostActive(const std::string& ipAddress) {
    std::string command = PING_COMMAND + ipAddress + " > nul 2>&1";
    int result = std::system(command.c_str());
    return result == 0;
}

std::vector<std::string> scanNetwork(const std::string& baseIp, int start, int end) {
    std::vector<std::string> activeHosts;

    for (int i = start; i <= end; ++i) {
        std::string ip = baseIp + "." + std::to_string(i);
        if (isHostActive(ip)) {
            activeHosts.push_back(ip);
        }
    }

    return activeHosts;
}

int main() {
    setlocale(0, "");
    std::string baseIp;
    int startRange, endRange;

    std::cout << "Введите базовый IP (например, 192.168.1): ";
    std::cin >> baseIp;

    std::cout << "Введите начальный адрес (например, 1): ";
    std::cin >> startRange;

    std::cout << "Введите конечный адрес (например, 254): ";
    std::cin >> endRange;

    std::cout << "Сканирование сети...\n";
    auto activeHosts = scanNetwork(baseIp, startRange, endRange);

    if (!activeHosts.empty()) {
        std::cout << "Активные хосты:\n";
        for (const auto& host : activeHosts) {
            std::cout << host << "\n";
        }
    }
    else {
        std::cout << "Активных хостов не найдено.\n";
    }

    return 0;
}
